from flask import *
app=Flask(__name__)

@app.route("/")
def hello():
    return render_template('index.html')

@app.route("/soups")
def soups():
    return render_template('soups.html')

@app.route("/maincourse")
def maincourse():
    return render_template('maincourse.html')

@app.route("/Starters")
def Starters():
    return render_template('Starters.html')

@app.route("/desserts")
def desserts():
    return render_template('desserts.html')





@app.route("/chole")
def chole():
        return render_template('chole.html')

@app.route("/dal")
def dal():
        return render_template('dal.html')

@app.route("/biryani")
def biryani():
        return render_template('biryani.html')

@app.route("/paneer")
def paneer():
        return render_template('paneer.html')

@app.route("/aloo")
def aloo():
        return render_template('aloo.html')

@app.route("/paneerb")
def paneerb():
        return render_template('paneerb.html')


@app.route("/taco")
def taco():
        return render_template('taco.html')

@app.route("/lentil")
def lentil():
        return render_template('lentil.html')

@app.route("/lasagna")
def lasagna():
        return render_template('lasagna.html')

@app.route("/broccoli")
def broccoli():
        return render_template('broccoli.html')

@app.route("/bean")
def bean():
        return render_template('bean.html')

@app.route("/dahi")
def dahi():
        return render_template('dahi.html')

@app.route("/paneerk")
def paneerk():
        return render_template('paneerk.html')

@app.route("/samosa")
def samosa():
        return render_template('samosa.html')

@app.route("/mutton")
def mutton():
        return render_template('mutton.html')

@app.route("/chicken")
def chicken():
        return render_template('chicken.html')

@app.route("/malai")
def malai():
        return render_template('malai.html')



@app.route("/nutella")
def nutella():
        return render_template('nutella.html')

@app.route("/peanut")
def peanut():
        return render_template('peanut.html')

@app.route("/Chocolate")
def Chocolate():
        return render_template('Chocolate.html')

@app.route("/Pastry")
def Pastry():
        return render_template('Pastry.html')

@app.route("/rasmalai")
def rasmalai():
        return render_template('rasmalai.html')




if __name__=="__main__":
    app.run(debug=True)